forever stop 0
~/_gc/srv/startup.sh
